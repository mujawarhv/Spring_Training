package com.cdac.service;

import java.util.List;

import com.cdac.dao.EmployeeDao;
import com.cdac.dao.EmployeeDaoImpl;
import com.cdac.model.Employee;

public class EmployeeServiceImpl implements EmployeeService{
	private EmployeeDao employeeDao = new EmployeeDaoImpl();
	@Override
	public boolean addEmployee(Employee employee) {
		boolean result = employeeDao.createEmployee(employee);
		return result;
	}
	@Override
	public Employee findEmployeeByEmployeeId(int employeeId) {
		Employee employee = employeeDao.readEmployeeByEmployeeId(employeeId);
		return employee;
	}
	@Override
	public List<Employee> findAllEmployees() {
		List<Employee> list = employeeDao.readAllEmployees();
		return list;
	}
}
