package com.cdac.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cdac.config.AppConfig;
import com.cdac.exceptions.EmployeeNotFoundException;
import com.cdac.model.Address;
import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;

public class Main {
	private static ApplicationContext context;
	public static void main(String[] args) {
		context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		Employee emp = getContext().getBean("employee", Employee.class);
		emp.setEmployeeId(10005);
		emp.setEmployeeName("Makarand Bhoir");
		emp.setEmployeeSalary(7000);
		
		Address address = getContext().getBean("address", Address.class);
		address.setAddressId(10);
		address.setCity("Mumbai");
		address.setPin("400706");
		address.setStreet("ABC Road");
		
		emp.setAddress(address);
		
		EmployeeService service = getContext().getBean("employeeServiceImpl", EmployeeService.class);
		boolean result = service.addEmployee(emp);
		if(result) {
			System.out.println("Employee is added.");
		}
		try {
			Employee emp2 = service.findEmployeeByEmployeeId(emp.getEmployeeId());
			System.out.println(emp2);
		}catch(EmployeeNotFoundException e) {
			System.out.println(e);
		}
	}
	public static ApplicationContext getContext() {
		return context;
	}
}
