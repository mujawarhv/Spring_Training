package com.cdac.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.cdac.model.Employee;
import com.cdac.utils.JpaUtils;
@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	private EntityManager entityManager;
	
	public EmployeeDaoImpl() {
		entityManager = JpaUtils.getEntityManager();
	}
		
	@Override
	public boolean createEmployee(Employee employee) {
		entityManager.getTransaction().begin();
		entityManager.persist(employee);
		entityManager.getTransaction().commit();
		return true;
	}
	@Override
	public Employee readEmployeeByEmployeeId(int employeeId) {
		Employee employee = entityManager.find(Employee.class, employeeId);
		return employee;
	}
	@Override
	public List<Employee> readAllEmployees() {
		return null;
	}
	@Override
	public boolean updateEmployee(Employee employee) {
		return false;
	}
	@Override
	public boolean deleteEmployee(int employeeId) {
		return false;
	}
	
}
