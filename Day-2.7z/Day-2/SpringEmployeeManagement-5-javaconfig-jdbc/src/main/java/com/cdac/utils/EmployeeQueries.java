package com.cdac.utils;

public class EmployeeQueries {
	public final static String INSERT_EMPLOYEE = "insert into employee(employee_id, employee_name, employee_salary) values(?, ?, ?)";
	public final static String DELETE_EMPLOYEE_BY_ID = "delete from employee where employee_id = ?";
	public final static String UPDATE_EMPLOYEE = "update employee set employee_name=?, employee_salary=? where employee_id=?";
	public final static String GET_ALL_EMPLOYEES = "select * from employee";
	public final static String GET_EMPLOYEE_BY_ID = "select * from employee where employee_id = ?";
}
