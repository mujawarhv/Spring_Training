package com.cdac.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.cdac.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
	private JdbcTemplate template;
	
	private final static String INSERT_EMPLOYEE = "insert into employee(employee_id, employee_name, employee_salary) values(?, ?, ?)";
	private final static String DELETE_EMPLOYEE_BY_ID = "delete from employee where employee_id = ?";
	private final static String UPDATE_EMPLOYEE = "update employee set employee_name=?, employee_salary=? where employee_id=?";
	private final static String GET_ALL_EMPLOYEES = "select * from employee";
	private final static String GET_EMPLOYEE_BY_ID = "select * from employee where employee_id = ?";
	
	public boolean createEmployee(Employee employee) {
		int result = template.update(INSERT_EMPLOYEE, employee.getEmployeeId(), employee.getEmployeeName(), employee.getEmployeeSalary());
		if(result ==1) {
			return true;
		}
		return false;
	}
	public Employee readEmployeeByEmployeeId(int employeeId) {
		Employee employee = template.queryForObject(GET_EMPLOYEE_BY_ID, new Object[] {employeeId}, new EmployeeRowMapper());
		return employee;
	}
	public List<Employee> readAllEmployees() {
		List<Employee> list = template.query(GET_ALL_EMPLOYEES, new EmployeeRowMapper());
		return list;
	}
	@Override
	public boolean updateEmployee(Employee employee) {
		int result = template.update(UPDATE_EMPLOYEE, employee.getEmployeeName(), employee.getEmployeeSalary(), employee.getEmployeeId());
		if(result == 1) {
			return true;
		}
		return false;
	}
	@Override
	public boolean deleteEmployee(int employeeId) {
		int result = template.update(DELETE_EMPLOYEE_BY_ID, employeeId);
		if(result == 1) {
			return true;
		}
		return false;
	}
	public JdbcTemplate getTemplate() {
		return template;
	}
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
}
