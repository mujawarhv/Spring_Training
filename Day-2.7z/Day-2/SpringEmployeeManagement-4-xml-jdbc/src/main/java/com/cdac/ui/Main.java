package com.cdac.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.exceptions.EmployeeNotFoundException;
import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-Configuration.xml");
		Employee emp = context.getBean("employee", Employee.class);
		emp.setEmployeeId(10002);
		emp.setEmployeeName("Makarand Bhoir");
		emp.setEmployeeSalary(7000);
		
		EmployeeService service = context.getBean("service", EmployeeService.class);
		boolean result = service.addEmployee(emp);
		if(result) {
			System.out.println("Employee is added.");
		}
		try {
			Employee emp2 = service.findEmployeeByEmployeeId(emp.getEmployeeId());
			System.out.println(emp2);
		}catch(EmployeeNotFoundException e) {
			System.out.println(e);
		}
	}
}
