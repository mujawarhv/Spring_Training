package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.EmployeeDao;
import com.cdac.model.Employee;
@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeDao employeeDao;
	@Override
	public boolean addEmployee(Employee employee) {
		boolean result = getEmployeeDao().createEmployee(employee);
		return result;
	}
	@Override
	public Employee findEmployeeByEmployeeId(int employeeId) {
		Employee employee = getEmployeeDao().readEmployeeByEmployeeId(employeeId);
		return employee;
	}
	@Override
	public List<Employee> findAllEmployees() {
		List<Employee> list = getEmployeeDao().readAllEmployees();
		return list;
	}
	public EmployeeDao getEmployeeDao() {
		return employeeDao;
	}
	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}
}
