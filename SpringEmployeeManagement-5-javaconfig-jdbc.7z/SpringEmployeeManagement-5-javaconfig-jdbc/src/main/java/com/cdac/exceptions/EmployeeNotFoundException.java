package com.cdac.exceptions;

public class EmployeeNotFoundException extends RuntimeException {
	private int employeeId;
	public EmployeeNotFoundException(int employeeId) {
		this.employeeId = employeeId;
	}
	public String toString() {
		return "Employee ["+employeeId+"] not found.";
	}
}
