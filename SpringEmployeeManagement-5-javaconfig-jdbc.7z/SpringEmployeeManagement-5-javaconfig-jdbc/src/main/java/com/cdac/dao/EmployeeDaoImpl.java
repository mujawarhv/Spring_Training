package com.cdac.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.model.Employee;
import com.cdac.utils.EmployeeQueries;
@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	private JdbcTemplate template;
		
	public boolean createEmployee(Employee employee) {
		int result = template.update(EmployeeQueries.INSERT_EMPLOYEE, employee.getEmployeeId(), employee.getEmployeeName(), employee.getEmployeeSalary());
		if(result ==1) {
			return true;
		}
		return false;
	}
	public Employee readEmployeeByEmployeeId(int employeeId) {
		Employee employee = template.queryForObject(EmployeeQueries.GET_EMPLOYEE_BY_ID, new Object[] {employeeId}, new EmployeeRowMapper());
		return employee;
	}
	public List<Employee> readAllEmployees() {
		List<Employee> list = template.query(EmployeeQueries.GET_ALL_EMPLOYEES, new EmployeeRowMapper());
		return list;
	}
	@Override
	public boolean updateEmployee(Employee employee) {
		int result = template.update(EmployeeQueries.UPDATE_EMPLOYEE, employee.getEmployeeName(), employee.getEmployeeSalary(), employee.getEmployeeId());
		if(result == 1) {
			return true;
		}
		return false;
	}
	@Override
	public boolean deleteEmployee(int employeeId) {
		int result = template.update(EmployeeQueries.DELETE_EMPLOYEE_BY_ID, employeeId);
		if(result == 1) {
			return true;
		}
		return false;
	}
	public JdbcTemplate getTemplate() {
		return template;
	}
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
}
