package com.cdac.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cdac.config.AppConfig;
import com.cdac.exceptions.EmployeeNotFoundException;
import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		Employee emp = context.getBean("employee", Employee.class);
		emp.setEmployeeId(10001);
		emp.setEmployeeName("Makarand Bhoir");
		emp.setEmployeeSalary(7000);
		
		EmployeeService service = context.getBean("employeeServiceImpl", EmployeeService.class);
		boolean result = service.addEmployee(emp);
		if(result) {
			System.out.println("Employee is added.");
		}
		try {
			Employee emp2 = service.findEmployeeByEmployeeId(emp.getEmployeeId());
			System.out.println(emp2);
		}catch(EmployeeNotFoundException e) {
			System.out.println(e);
		}
	}
}
