package com.cdac.ui;

import com.cdac.exceptions.EmployeeNotFoundException;
import com.cdac.model.Employee;
import com.cdac.service.EmployeeService;
import com.cdac.service.EmployeeServiceImpl;

public class Main {
	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.setEmployeeId(10001);
		emp.setEmployeeName("Makarand Bhoir");
		emp.setEmployeeSalary(7000);
		
		EmployeeService service = new EmployeeServiceImpl();
		boolean result = service.addEmployee(emp);
		if(result) {
			System.out.println("Employee is added.");
		}
		try {
			Employee emp2 = service.findEmployeeByEmployeeId(1);
			System.out.println(emp2);
		}catch(EmployeeNotFoundException e) {
			System.out.println(e);
		}
	}
}
