package com.cdac.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cdac.config.JavaConfig;
import com.cdac.model.Employee;

public class Main {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfig.class);
		Employee employee = context.getBean("employee", Employee.class);
		System.out.println(employee);
		System.out.println(employee.getAddress());
	}
}
