package com.cdac.dao;

import java.util.ArrayList;
import java.util.List;

import com.cdac.exceptions.EmployeeNotFoundException;
import com.cdac.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {
	private static List<Employee> employees = new ArrayList<>();
	
	public boolean createEmployee(Employee employee) {
		boolean result = employees.add(employee);
		return result;
	}
	public Employee readEmployeeByEmployeeId(int employeeId) {
		for(Employee emp : employees) {
			if(emp.getEmployeeId() == employeeId) {
				return emp;
			}
		}
		throw new EmployeeNotFoundException(employeeId);
	}
	public List<Employee> readAllEmployees() {
		return employees;
	}
}
