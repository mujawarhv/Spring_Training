package com.cdac.service;

import java.util.List;

import com.cdac.dao.EmployeeDao;
import com.cdac.dao.EmployeeDaoImpl;
import com.cdac.model.Employee;

public class EmployeeServiceImpl implements EmployeeService{
	private EmployeeDao employeeDao;
	
	@Override
	public boolean addEmployee(Employee employee) {
		boolean result = getEmployeeDao().createEmployee(employee);
		return result;
	}
	@Override
	public Employee findEmployeeByEmployeeId(int employeeId) {
		Employee employee = getEmployeeDao().readEmployeeByEmployeeId(employeeId);
		return employee;
	}
	@Override
	public List<Employee> findAllEmployees() {
		List<Employee> list = getEmployeeDao().readAllEmployees();
		return list;
	}
	public EmployeeDao getEmployeeDao() {
		return employeeDao;
	}
	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}
}
