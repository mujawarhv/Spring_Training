package com.cdac.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

import com.cdac.model.Address;
import com.cdac.model.Employee;

@Lazy
@Configuration
@ComponentScan(basePackages= {"com.cdac"})
public class JavaConfig {
	@Bean(name="employee")
	@Scope(scopeName="singleton")
	public Employee getEmployee() {
		Employee employee = new Employee();
		//employee.setAddress(getAddress());
		return employee;
	}
	
	@Primary
	@Bean(name="address1")
	@Scope(scopeName="singleton")
	public Address getAddress() {
		Address address = new Address();
		address.setCity("Mumbai");
		return address;
	}
}
