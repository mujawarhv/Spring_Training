package com.cdac.resultset.row.typed;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.cdac.Customer;
import com.cdac.CustomerListQuery;

public class ParameterizedRowMapperCustomerListQuery
implements CustomerListQuery {

  private JdbcTemplate simpleJdbc;
  
  public ParameterizedRowMapperCustomerListQuery(DataSource dataSource) {
    this.simpleJdbc = new JdbcTemplate(dataSource);
  }

  public List<Customer> getCustomers() {
    return this.simpleJdbc.<Customer>query(
      "select id, name from customer", customerRowMapper);
  }

  private static final RowMapper<Customer> customerRowMapper =
    new RowMapper<Customer>(){
    public Customer mapRow(ResultSet rslt, int rowNum) throws SQLException {
      return new Customer(rslt.getString("id"), rslt.getString("name"));
    }
  };
}
