package com.cdac.resultset.row;

import java.util.List;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.Customer;
import com.cdac.CustomerListQuery;

public class Main {

  public static void main(String[] args) throws Exception {
    
    BeanFactory beanFactory =
      new ClassPathXmlApplicationContext(new String[]{
        "/com/cdac/resultset/row/applicationContext.xml",
        "/com/cdac/util/dataSourceContext.xml"});
    
    CustomerListQuery query = 
      (CustomerListQuery) beanFactory.getBean("customerListQuery");
    
    List<Customer>customers = query.getCustomers();

    for(Customer customer : customers){
      System.out.println(customer);
    }
  }
}
