package com.cdac.util;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.List;

import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 * DataSource implementation for an embedded Derby database instance.
 */
public class CustomerDataSource extends DriverManagerDataSource {

	/**
	 * Creates a new CustomerDataSource instance.
	 * <p>
	 * Initializes the instance with a custom database name and optionally a list of
	 * setup scripts to be sourced from the class path and executed.
	 * 
	 * @param databaseName required
	 * @param scriptPaths  optional
	 * @throws IllegalArgumentException for parameter spec violations
	 */
	public CustomerDataSource(final String driverClassName, final String url, final String username,
			final String password, String... scriptPaths) {
		// configure DataSource
		super.setDriverClassName(driverClassName);
		super.setUrl(url);
		super.setUsername(username);
		super.setPassword(password);

		// init tables and seed data
		if (scriptPaths != null) {
			for (String scriptPath : scriptPaths) {
				List<SqlCommand> commands = null;
				try {
					commands = SqlCommand.parseResourcePath(scriptPath);
				} catch (IOException e) {
					throw new IllegalStateException("Error: I/O for SQL scripts Failed to load: " + scriptPath, e);
				}
				for (SqlCommand sqlCmd : commands) {
					try {
						sqlCmd.setIgnoreError(true).execute(this);
					} catch (SQLException e) {
					}
				}
			}
		}
	}
}
