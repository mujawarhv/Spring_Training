package com.cdac.parameter.object;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.cdac.Customer;
import com.cdac.CustomerQuery;

public class ObjectParameterCustomerQuery implements CustomerQuery {

  private JdbcTemplate jdbc;

  public ObjectParameterCustomerQuery(DataSource dataSource) {
    this.jdbc = new JdbcTemplate(dataSource);
  }

  public Customer getCustomerByName(String customerName) {
    try{
      return this.jdbc.queryForObject(
        "select id, name from customer where name = ?",
        customerRowMapper,
        customerName);
    }
    catch(EmptyResultDataAccessException e){
      return null;
    }
  }


  private RowMapper<Customer> customerRowMapper =
    new RowMapper<Customer>(){
      public Customer mapRow(ResultSet rslt, int rowNum) throws SQLException {
        return new Customer(rslt.getString("id"), rslt.getString("name"));
      }
    };
}
