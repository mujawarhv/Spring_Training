package com.cdac.parameter.object;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.Customer;
import com.cdac.CustomerQuery;

public class Main {

  public static void main(String[] args) throws Exception {
    
    BeanFactory beanFactory =
      new ClassPathXmlApplicationContext(new String[]{
        "/com/cdac/parameter/object/applicationContext.xml",
        "/com/cdac/util/dataSourceContext.xml"});
    
    CustomerQuery query = (CustomerQuery) beanFactory.getBean("customerQuery");
    
    Customer result = query.getCustomerByName("Java Joe");
    
    System.out.println(result);
  }
}
