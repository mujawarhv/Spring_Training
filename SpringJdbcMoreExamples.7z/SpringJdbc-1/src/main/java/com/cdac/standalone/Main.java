package com.cdac.standalone;
import com.cdac.Customer;
import com.cdac.CustomerQuery;
import com.cdac.JdbcCustomerQuery;
import com.cdac.util.CustomerDataSource;

public class Main {

  public static void main(String[] args) throws Exception {
    CustomerDataSource dataSource = new CustomerDataSource("oracle.jdbc.driver.OracleDriver", "jdbc:oracle:thin:@localhost:1521:XE", "hr", "hr", "/setup.sql");
    CustomerQuery query = new JdbcCustomerQuery(dataSource);
    Customer customer = query.getCustomerByName("Java Joe");
    System.out.println(customer);
  }

}
